package com.scon.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NcategoryVO {
	private int ccode;
	private String cname;
}
